AR CAT
- cat.glb = โมเดลแมว 3D
- target.jpg = รูปแท็กที่คุณส่งมา
- compile.html = สร้าง targets.mind จากรูปแท็ก
- ar.html = หน้า WebAR

หมายเหตุ: การเปิดกล้องต้องผ่าน HTTPS (หรือ localhost)
ขั้นตอน: compile.html -> สร้าง targets.mind -> วาง targets.mind ในโฟลเดอร์ -> เปิด ar.html
